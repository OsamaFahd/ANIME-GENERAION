<?php
add_filter( 'rwmb_meta_boxes', 'your_prefix_register_meta_boxes' );
function your_prefix_register_meta_boxes( $meta_boxes )
{
	$prefix = 'snap_';
	$meta_boxes[] = array(
		'id' => 'animeinfo',
		'title' => __( 'Informasi Anime', 'meta-box' ),
		'pages' => array( 'anime', 'batch' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'id' => $prefix . 'cover',
				'type' => 'image_advanced',
				'name' => esc_html__( 'Cover Anime' ),
				'desc' => esc_html__( 'Input Anime Cover' ),
				'max_file_uploads' => '1',
				'max_status' => false,
			),
			array(
				'name'  => __( 'Judul Anime', 'meta-box' ),
				'id'    => "{$prefix}jdlanime",
				'desc'  => __( 'Input Anime Title', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Japanese', 'meta-box' ),
				'id'    => "{$prefix}japanese",
				'desc'  => __( 'Masukan Judul Jepang', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'     => __( 'Type Anime', 'meta-box' ),
				'id'       => "{$prefix}type",
				'type'     => 'select',
				'options'  => array(
					'TV' => __( 'TV Series', 'meta-box' ),
					'Movie' => __( 'Movie', 'meta-box' ),
                    			'BD' => __( 'BD Series', 'meta-box' ),
					'OVA' => __( 'OVA', 'meta-box' ),
					'ONA' => __( 'ONA', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'TV',
			),
			array(
				'name'     => __( 'Status', 'meta-box' ),
				'id'       => "{$prefix}status",
				'type'     => 'select',
				'options'  => array(
					'Ongoing' => __( 'Ongoing', 'meta-box' ),
					'Complete' => __( 'Complete', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'Ongoing',
			),
			array(
				'name'  => __( 'Year', 'meta-box' ),
				'id'    => "{$prefix}year",
				'desc'  => __( 'Tahun Rilis', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Episode', 'meta-box' ),
				'id'    => "{$prefix}eps",
				'desc'  => __( 'Total Episode', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Durasi', 'meta-box' ),
				'id'    => "{$prefix}duration",
				'desc'  => __( 'Lama Durasi', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Aired', 'meta-box' ),
				'id'    => "{$prefix}aired",
				'desc'  => __( 'Tanggal Aired', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Studio', 'meta-box' ),
				'id'    => "{$prefix}studio",
				'desc'  => __( 'Studio', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Skor', 'meta-box' ),
				'id'    => "{$prefix}skor",
				'desc'  => __( 'Skor', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name' => __('Trailer On/Off', 'textdomain'),
				'id'   => "{$prefix}trailer-status",
				'type' => 'checkbox',
				'desc' => 'On/Off',
				'std'  => 0,
			),
			array(
				'name' => __( 'Trailer Anime', 'meta-box' ),
				'id'   => "{$prefix}trailer",
				'desc'  => __( 'Input "src" trailer video from embed', 'meta-box' ),
				'type' => 'oembed',
			),
         )			
	);
	$meta_boxes[] = array(
		'id' => 'episode-info',
		'title' => __( 'Episode Info', 'meta-box' ),
	        'pages' => array( 'post' ),
		'fields' => array(
			array(
				'type' => 'heading',
				'name' => __('Data Episode Anime', 'textdomain'),
			),
			array(
				'name' => __( 'Episode', 'meta-box' ),
				'id'   => "{$prefix}episode-anime",
				'desc'  => __( 'Masukkan episode sekarang', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Tambahan', 'meta-box' ),
				'id'    => "{$prefix}added",
				'desc'  => __( 'Tambahan Episode', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'    => __( 'Anime', 'meta-box' ),
				'id'      => "{$prefix}anime",
				'type'    => 'post',

				// Post type
				'post_type' => 'anime',
				// Field type, either 'select' or 'select_advanced' (default)
				'field_type' => 'select_advanced',
				// Query arguments (optional). No settings means get all published posts
				'query_args' => array(
					'post_status'    => 'publish',
					'orderby'	 => 'title',
					'order'		 => 'ASC',
					'posts_per_page' => - 1,
				)
			),
			array(
				'id' => '{$prefix}credit',
				'desc' => 'Input the name of the source',
				'name' => __('Credit Name', 'textdomain'),
				'type'  => 'text',
			),			
		)
	);
	$meta_boxes[] = array(
		'id' => 'batch',
		'title' => __( 'Batch', 'meta-box' ),
	        'pages' => array( 'batch' ),
		'fields' => array(
		    array(
				'name'    => __( 'Streaming Anime', 'meta-box' ),
				'id'      => "{$prefix}anime",
				'type'    => 'post',

				// Post type
				'post_type' => 'anime',
				// Field type, either 'select' or 'select_advanced' (default)
				'field_type' => 'select_advanced',
				// Query arguments (optional). No settings means get all published posts
				'query_args' => array(
					'post_status'    => 'publish',
					'orderby'	 => 'title',
					'order'		 => 'ASC',
					'posts_per_page' => - 1,
				)
			),
			array(
				'name'  => __( 'Link Download', 'meta-box' ),
				'id'    => "{$prefix}download-url",
				'desc'  => __( 'Url download batch', 'meta-box' ),
				'type'  => 'wysiwyg',
			),
		)
	);
	$meta_boxes[] = array(
		'id' => 'ostinfo',
		'title' => __( 'OST Info', 'meta-box' ),
	        'pages' => array( 'ost' ),
		'fields' => array(
			array(
				'name' => __( 'Judul', 'meta-box' ),
				'id'   => "{$prefix}judulost",
				'desc'  => __( 'Masukkan Judul OST', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name' => __( 'Format', 'meta-box' ),
				'id'   => "{$prefix}format",
				'desc'  => __( 'Masukkan Format OST', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'  => __( 'Penyanyi', 'meta-box' ),
				'id'    => "{$prefix}singer",
				'desc'  => __( 'Nama Penyanyi', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'     => __( 'Tipe OST', 'meta-box' ),
				'id'       => "{$prefix}tipeost",
				'type'     => 'select',
				'options'  => array(
					'Opening' => __( 'Opening', 'meta-box' ),
					'Ending' => __( 'Ending', 'meta-box' ),
					'Insert Song' => __( 'Insert Song', 'meta-box' ),
				),
				'multiple'    => false,
			),
			array(
				'name'  => __( 'Bitrate', 'meta-box' ),
				'id'    => "{$prefix}bitrate",
				'desc'  => __( 'Bitrate OST', 'meta-box' ),
				'type'  => 'text',
			),
			array(
				'name'    => __( 'Anime', 'meta-box' ),
				'id'      => "{$prefix}anime",
				'type'    => 'post',

				// Post type
				'post_type' => 'anime',
				// Field type, either 'select' or 'select_advanced' (default)
				'field_type' => 'select_advanced',
				// Query arguments (optional). No settings means get all published posts
				'query_args' => array(
					'post_status'    => 'publish',
					'orderby'	 => 'title',
					'order'		 => 'ASC',
					'posts_per_page' => - 1,
				)
			),
			array(
				'name'  => __( 'Link Download', 'meta-box' ),
				'id'    => "{$prefix}download-url",
				'desc'  => __( 'Url download ost', 'meta-box' ),
				'type'  => 'url',
			),
		)
		
	);
	return $meta_boxes;
}

add_filter('rwmb_meta_boxes', 'kdezign_metabox');
function kdezign_metabox($metabox){
	$metabox[] = array(
		'title' => __('Streaming Post', 'textdomain'),
		'post_types' => 'post',
		'fields' => array(
			array(
				'type' => 'heading',
				'name' => __('Data Streaming Anime', 'textdomain'),
			),
			array(
				'name' => __('Streaming Status', 'textdomain'),
				'id'   => "status-streaming",
				'type' => 'checkbox',
				'desc' => 'On/Off',
				'std'  => 0,
			),
			array(
				'name'  => __( 'Embed Video', 'meta-box' ),
				'id'    => "embed",
				'desc'  => __( 'Embed Video', 'meta-box' ),
				'type'  => 'textarea',
				'clone' => 'true',
			),
		),
	);
	return $metabox;
}