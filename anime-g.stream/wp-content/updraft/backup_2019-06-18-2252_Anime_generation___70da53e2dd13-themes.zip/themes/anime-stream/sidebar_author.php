<div class="sidebar" style='margin-bottom:-20px;'>
<div class="section"><div class="area">
<section class="postauthor boxs" style="width: 100%; overflow: hidden;">
<div class="authorava opacity80">
<?php echo get_avatar( get_the_author_meta( 'ID' ), 100 ); ?>
</div>
<div class="authorright">
<h4>الرافع</h4>
<h2><?php the_author(); ?></h2>
</div>
</section>
</div></div>
</div>