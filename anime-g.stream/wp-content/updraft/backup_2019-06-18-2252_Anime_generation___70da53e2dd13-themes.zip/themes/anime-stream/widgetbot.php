<div class="rekomf">
<?php
if(is_active_sidebar('bot-widget')){
dynamic_sidebar('bot-widget');
}
?>

</div>