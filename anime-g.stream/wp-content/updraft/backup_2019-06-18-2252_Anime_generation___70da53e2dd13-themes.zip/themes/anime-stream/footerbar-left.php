<div class="footerbar">
<?php
if(is_active_sidebar('footer-left')){
	dynamic_sidebar('footer-left');
}
?>
</div>