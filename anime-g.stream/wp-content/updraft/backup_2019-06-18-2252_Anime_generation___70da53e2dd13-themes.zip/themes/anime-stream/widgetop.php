<div class="rekomf">
<?php
if(is_active_sidebar('top-widget')){
dynamic_sidebar('top-widget');
}
?>
</div>