<div class="footerbar">
<?php
if(is_active_sidebar('footer-right')){
	dynamic_sidebar('footer-right');
}
?>
</div>