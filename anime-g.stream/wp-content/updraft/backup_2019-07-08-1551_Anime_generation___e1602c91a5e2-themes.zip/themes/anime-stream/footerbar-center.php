<div class="footerbar">
<?php
if(is_active_sidebar('footer-center')){
	dynamic_sidebar('footer-center');
}
?>
</div>