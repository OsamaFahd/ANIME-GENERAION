<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="http://docs.getshortcodes.com/category/15-getting-started" target="_blank"><?php _e( 'Getting started', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="http://docs.getshortcodes.com/article/32-plugin-settings" target="_blank"><?php _e( 'Plugin settings overview', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="http://docs.getshortcodes.com/article/33-custom-css-editor" target="_blank"><?php _e( 'How to use Custom CSS editor', 'shortcodes-ultimate' ); ?></a></li>
</ul>
