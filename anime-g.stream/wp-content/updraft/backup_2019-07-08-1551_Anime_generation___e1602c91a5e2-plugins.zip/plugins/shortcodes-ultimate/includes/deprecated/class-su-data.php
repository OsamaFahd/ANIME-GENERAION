<?php

if ( ! class_exists( 'Su_Data' ) ) {

	/**
	 *
	 *
	 * @deprecated 5.0.5
	 */
	class Su_Data {

		/**
		 *
		 *
		 * @deprecated 5.0.5
		 */
		public static function icons() {
			return su_get_config( 'icons' );
		}

	}

}
