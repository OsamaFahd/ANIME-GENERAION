<?php
/**
 * Admin controller class.
 */
class FMAdminController {
  /**
   * PLUGIN = 2 points to Contact Form Maker
   */
  const PLUGIN = 1;
}