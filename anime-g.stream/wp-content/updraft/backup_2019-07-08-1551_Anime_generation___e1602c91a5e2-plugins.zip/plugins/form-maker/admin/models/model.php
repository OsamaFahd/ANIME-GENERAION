<?php
/**
 * Admin model class.
 */
class FMAdminModel {
  /**
   * PLUGIN = 2 points to Contact Form Maker
   */
  const PLUGIN = 1;
}