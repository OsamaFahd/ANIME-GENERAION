angular.module('ThemeParams', []).controller('FMTheme', function($scope) {
    $scope.DefaultVar = DefaultVar;
});